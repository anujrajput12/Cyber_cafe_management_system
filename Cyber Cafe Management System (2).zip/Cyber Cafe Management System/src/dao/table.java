/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import javax.swing.JOptionPane;
//import dao.DbOperations;

/**
 *  `
 * @author akash
 */
public class table {
    
    public static void main(String[] args){
        try{
        
       String userTable = "create table user (id int AUTO_INCREMENT primary key, name varchar(200), email varchar(200), mobileNumber varchar(10),address varchar(100), password varchar(200), securityQuestion varchar(200), answer varchar(200), status varchar(20), UNIQUE(email))";
       String adminDetails ="insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('Admin','admin@gmail.com','1234567890','India','tiger','What primary school did you attend?','ABC','true')";
       DbOperations.setDataOrDelete(userTable,"user table created successfully");
       DbOperations.setDataOrDelete(adminDetails,"Admin details added successfully");
       String akashDetails ="insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('Akash','akash@gmail.com','2134567890','India','tiger','What primary school did you attend?','ABC','true')";
        DbOperations.setDataOrDelete(akashDetails,"Admin details added successfully");
        
        String anujDetails ="insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('Anuj','anuj@gmail.com','1243567890','India','tiger','What primary school did you attend?','ABC','true')";
        DbOperations.setDataOrDelete(anujDetails,"Admin details added successfully");
        
        String kishanDetails ="insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('Kishan','kishan@gmail.com','1234567809','India','tiger','What primary school did you attend?','ABC','true')";
        DbOperations.setDataOrDelete(kishanDetails,"Admin details added successfully");
        
        String ritikaDetails ="insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('Ritika','ritika@gmail.com','1234568790','India','tiger','What primary school did you attend?','ABC','true')";
        DbOperations.setDataOrDelete(ritikaDetails,"Admin details added successfully");
        }
        catch(Exception e){
             JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
